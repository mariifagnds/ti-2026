# PetCare — Sistema de Gestão Veterinária

Este é o meu projeto de sistema web para uma clínica veterinária fictícia. A ideia é reunir em um só lugar algumas tarefas comuns da rotina: cadastrar tutores e animais, organizar consultas e acompanhar os itens do estoque.

## O que o sistema oferece
- Um painel inicial com um resumo dos cadastros e das próximas consultas.
- Cadastro, consulta, edição e exclusão de tutores, animais e consultas.
- Cadastro e remoção de medicamentos do estoque.
- Pesquisa de registros e filtro de consultas por data.
- API que disponibiliza os dados de animais e tutores em JSON.

## Tecnologias que usei
- Python e Flask para a aplicação e suas rotas.
- SQLite para guardar os dados.
- HTML, CSS e Jinja2 para montar as páginas.
- GitHub e Render para organizar e publicar o projeto.

## Como executar no computador
Você precisa ter Python 3.10 ou superior instalado.

1. Abra a pasta do projeto no terminal.
2. (Opcional) Crie um ambiente virtual:
   - Windows: `python -m venv .venv` e depois `.venv\\Scripts\\activate`
   - macOS/Linux: `python3 -m venv .venv` e depois `source .venv/bin/activate`
3. Instale o que o projeto precisa: `pip install -r requirements.txt`
4. Inicie a aplicação: `python app.py`
5. Abra `http://127.0.0.1:5000` no navegador.

O banco de dados é criado automaticamente dentro da pasta `instance`, quando a aplicação é executada.

## Como os dados estão organizados
Separei os dados em quatro tabelas:
- `tutores`: guarda o nome, telefone e e-mail dos responsáveis.
- `animais`: guarda os dados dos pets e faz referência ao tutor responsável.
- `consultas`: registra data, horário, motivo e situação do atendimento de cada animal.
- `medicamentos`: guarda nome, quantidade e validade dos itens do estoque.

As tabelas de animais e tutores se relacionam pela chave `tutor_id`. Já as consultas se relacionam com os animais pela chave `animal_id`. Nas listagens, usei comandos SQL com `JOIN`, `WHERE` e `ORDER BY`.

## Lógica de programação
Para praticar lógica, implementei uma ordenação Selection Sort que organiza os animais pelo nome e uma função de busca linear que procura um animal pelo nome. Também utilizei funções, condicionais e laços em diferentes partes do sistema.

## Endpoints da API
- `GET /api/animais`: retorna os animais cadastrados e o nome do tutor.
- `GET /api/tutores`: retorna os tutores cadastrados.

## Publicação no Render
Para publicar, envie os arquivos para um repositório público no GitHub e crie um Web Service no Render conectado a esse repositório.

- Build Command: `pip install -r requirements.txt`
- Start Command: `gunicorn app:app`

Você também pode configurar uma variável `SECRET_KEY` no painel do Render.

**Atenção:** o armazenamento local de serviços gratuitos pode ser temporário. Isso significa que os dados do SQLite podem ser perdidos em reinicializações ou novos deploys. Para manter os dados em produção, é necessário usar um disco persistente compatível com o plano ou migrar o banco para PostgreSQL.

## Onde aparecem as unidades curriculares
- **UC30:** algoritmo Selection Sort, busca linear, funções, condicionais e laços.
- **UC31:** páginas HTML, estilos CSS, navegação e adaptação para telas menores.
- **UC32:** SQLite, tabelas relacionadas, operações CRUD e consultas SQL.
- **UC33:** rotas Flask, templates Jinja2 e endpoints que retornam JSON.
- **UC34:** organização e documentação das funcionalidades e da instalação neste README.
- **UC35:** arquivos de configuração para publicação. Ainda é necessário criar o repositório, fazer os commits e testar a aplicação publicada.

## Antes de entregar
Quero que o projeto represente o que aprendi, então preciso executar e testar as funções, revisar o código e adaptar este README com minhas próprias observações. Também preciso criar meu próprio histórico de pelo menos cinco commits no GitHub e conferir se o link do Render está funcionando.
